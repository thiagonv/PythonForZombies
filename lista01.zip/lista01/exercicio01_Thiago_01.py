numero1 = int(input("Insira o primeiro numero: "))
numero2 = int(input("Insira o segundo numero: "))

print (numero1 + numero2)
