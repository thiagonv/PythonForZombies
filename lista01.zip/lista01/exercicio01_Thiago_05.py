precoMercadoria = float(input("Preco Mercadoria: "))
percDesconto = float(input("Perc. Desconto: "))

valorDesconto = precoMercadoria * (percDesconto / 100)
precoMercadoria = precoMercadoria - valorDesconto

print(valorDesconto)
print(precoMercadoria)