valor = 2 ** 1000000
valorStr = str(valor)
print(len(valorStr))