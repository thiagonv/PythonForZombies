valorSalario = float(input("Informe o salario atual: "))
valorAumento = float(input("Informe % de aumento: "))

valorSalario = valorSalario + (valorSalario * (valorAumento / 100))

print(valorSalario)