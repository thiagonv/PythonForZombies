qtdCigarros = int(input("Quantidade de cigarros por dia: "))
qtdAnos = int(input("Quantidade de anos fumando: "))

qtdMinutos = qtdCigarros * 10

qtdDias = qtdAnos * 365

totalDiasFumando = qtdCigarros * qtdDias
totalMinutosFumando = totalDiasFumando * qtdMinutos

diasFumados = totalMinutosFumando / 1440

print(diasFumados)
