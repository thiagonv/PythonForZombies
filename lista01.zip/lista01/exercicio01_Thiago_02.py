valor = float(input("Insira o valor em metros: "))
print("Valor em milimetros: ", valor/1000)

