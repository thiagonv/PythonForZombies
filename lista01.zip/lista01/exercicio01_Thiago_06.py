distancia = float(input("Distancia: "))
velocidade = float(input("Velocidade media: "))

tempo = velocidade / distancia

print(tempo)