celsius = float(input("Temperatura em celsius: "))
fahrenheit = 9*(celsius/5) + 32

print(fahrenheit)