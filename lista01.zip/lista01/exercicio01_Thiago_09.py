km = float(input("KM percorrido: "))
dias = int(input("Dias alugado: "))

pagar = (dias * 60) + (km * 0.15)
print(pagar)