qtdDias = int(input("Quantidade de dias: "))
qtdHoras = int(input("Quantidade de horas: "))
qtdMinutos = int(input("Quantidade de minutos: "))
qtdSegundos = int(input("Quantidade de segundos: "))

qtdTotal = (qtdDias * 86400) + (qtdHoras * 3600) + (qtdMinutos * 60) + qtdSegundos

print(qtdTotal)