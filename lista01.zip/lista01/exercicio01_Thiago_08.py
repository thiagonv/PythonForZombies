fahrenheit = float(input("Temperatura em fahrenheit: "))
celsius = (fahrenheit - 32) / 1.8

print(celsius)